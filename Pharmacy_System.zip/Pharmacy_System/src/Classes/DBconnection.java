/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Classes;

import java.sql.DriverManager;
import java.sql.Connection;
import java.sql.SQLException;

public class DBconnection {
    
        public static Connection connect()
    {
        Connection con=null;
        
        try
        {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con=(Connection) DriverManager.getConnection("jdbc:mysql://localhost:3306/pharmacy_system?zeroDateTimeBehavior=CONVERT_TO_NULL", "root", "hansi");
        }
        catch(ClassNotFoundException | SQLException e)
        {
            System.out.println(e);
        }
        
        return con;
    }
}